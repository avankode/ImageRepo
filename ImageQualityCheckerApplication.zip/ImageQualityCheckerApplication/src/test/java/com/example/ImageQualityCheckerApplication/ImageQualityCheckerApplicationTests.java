package com.example.ImageQualityCheckerApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageQualityCheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
