package com.example.ImageQualityCheckerApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageQualityCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageQualityCheckerApplication.class, args);
	}

}
